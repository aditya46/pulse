// lazyload config
var MODULE_CONFIG = {
    screenfull:     [
                      'libs/screenfull/dist/screenfull.min.js'
                    ],
    stick_in_parent:[
                      'libs/sticky-kit/jquery.sticky-kit.min.js'
                    ]
  };
  
// jQuery plugin default options
var JP_CONFIG = {};
